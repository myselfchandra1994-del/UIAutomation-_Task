package com.example.labcorp.pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class HomePage {
    private WebDriver driver;
    private WebDriverWait wait;

    public HomePage(org.openqa.selenium.WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    private By careersLink = By.xpath("//a[contains(.,'Careers') and (contains(@href,'careers') or contains(@href,'Careers'))]");

    public void open(String url) {
        driver.get(url);
    }

    public void clickCareers() {
        wait.until(ExpectedConditions.elementToBeClickable(careersLink)).click();
    }
}
