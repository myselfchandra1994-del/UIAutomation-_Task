package com.example.labcorp.pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;

public class JobDetailsPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public JobDetailsPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    private By title = By.xpath("//h1 | //h1[contains(@class,'job-title')]");
    private By location = By.xpath("//*[contains(@class,'job-meta') or contains(@class,'location')]/descendant::span | //span[contains(@class,'location') or contains(@class,'job-location')]");
    private By jobId = By.xpath("//*[contains(.,'Job') and contains(.,'ID') or contains(.,'Req') or contains(@class,'job-id')]|//span[contains(text(),'2535528')]|//div[contains(text(),'2535528')]");
    private By applyNow = By.xpath("//a[contains(translate(.,'APPLY','apply'),'apply') and (contains(@href,'apply') or contains(@class,'apply'))]");

    public String getTitle() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(title)).getText().trim();
    }

    public String getLocation() {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(location)).getText().trim();
        } catch (Exception e) {
            return "";
        }
    }

    public String getJobId() {
        try {
            return driver.findElement(jobId).getText().trim();
        } catch (Exception e) {
            String url = driver.getCurrentUrl();
            if (url.contains("/job/")) {
                return url.substring(url.lastIndexOf('/')+1).split("-")[0];
            }
            return "";
        }
    }

    public void clickApply() {
        wait.until(ExpectedConditions.elementToBeClickable(applyNow)).click();
    }
}
