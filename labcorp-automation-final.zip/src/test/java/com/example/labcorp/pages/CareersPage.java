package com.example.labcorp.pages;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;
import java.util.List;

public class CareersPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public CareersPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(25));
    }

    private By searchInputXpath = By.xpath("//input[@type='search' or @aria-label='Search' or contains(@placeholder,'Search')]");
    private By resultLinks = By.xpath("//a[contains(@href,'/job/') and (contains(@class,'opening') or contains(.,''))]");

    public void searchFor(String text) {
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(searchInputXpath));
        input.clear();
        input.sendKeys(text);
        input.sendKeys(Keys.ENTER);
        waitUntilResults();
    }

    public void waitUntilResults() {
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(resultLinks));
    }

    public void openJobByTitle(String jobTitle) {
        waitUntilResults();
        List<WebElement> list = driver.findElements(resultLinks);
        for (WebElement el : list) {
            if (el.getText().trim().equalsIgnoreCase(jobTitle) || el.getText().toLowerCase().contains(jobTitle.toLowerCase())) {
                el.click();
                return;
            }
        }
        throw new RuntimeException("Job with title '" + jobTitle + "' not found in results.");
    }
}
