package com.example.labcorp.utils;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DriverFactory {
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    public static WebDriver getDriver() {
        if (driver.get() == null) {
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            driver.set(new ChromeDriver(options));
        }
        return driver.get();
    }

    public static void quitDriver() {
        if (driver.get() != null) {
            driver.get().quit();
            driver.remove();
        }
    }

    public static String takeScreenshot(String name) {
        try {
            WebDriver drv = getDriver();
            File src = ((TakesScreenshot)drv).getScreenshotAs(OutputType.FILE);
            String dir = "target/screenshots";
            Files.createDirectories(Paths.get(dir));
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
            String path = dir + "/" + name + "-" + timestamp + ".png";
            Files.copy(src.toPath(), Paths.get(path));
            return path;
        } catch (Exception e) {
            return null;
        }
    }
}
