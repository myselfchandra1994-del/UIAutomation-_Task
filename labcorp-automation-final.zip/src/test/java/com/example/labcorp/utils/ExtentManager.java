package com.example.labcorp.utils;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {
    private static ExtentReports extent;

    public synchronized static ExtentReports getExtentReports() {
        if (extent == null) {
            extent = new ExtentReports();
            ExtentSparkReporter reporter = new ExtentSparkReporter("target/extent-report/extent.html");
            reporter.config().setDocumentTitle("LabCorp Automation Report");
            reporter.config().setReportName("LabCorp UI & API Tests");
            extent.attachReporter(reporter);
        }
        return extent;
    }
}
