LabCorp Automation Final - Stable locators, ExtentReports, CI

Run UI tests: mvn test -Dcucumber.options="--tags @ui"
Run API tests: mvn test -Dcucumber.options="--tags @api"

Reports: After a run, ExtentReports HTML will be in target/extent-report/extent.html
CI: Jenkinsfile included and GitHub Actions workflow at .github/workflows/ci.yml
